package com.example.demo.interfaces;

public interface IOrganisationDto {
}
