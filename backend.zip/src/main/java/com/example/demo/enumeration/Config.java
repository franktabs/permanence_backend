package com.example.demo.enumeration;

public enum Config {
    MISE_A_JOUR,
    RECREATE,


}
