package com.example.demo.controllers;

import com.example.demo.dto.AbsenceDto;
import com.example.demo.dto.AbsenceDto;
import com.example.demo.dto.PersonnelDto;
import com.example.demo.dto.PlanningDto;
import com.example.demo.entities.Absence;
import com.example.demo.entities.Absence;
import com.example.demo.entities.Personnel;
import com.example.demo.entities.Planning;
import com.example.demo.repositories.AbsenceRepository;
import com.example.demo.services.AbsenceService;
import com.example.demo.utils.StringExtract;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.example.demo.controllers.DepartementController.convertDepartementToDto;
import static com.example.demo.controllers.PersonnelController.convertDtoToPersonnel;
import static com.example.demo.controllers.PersonnelController.convertPersonnelToDto;

@RestController
@CrossOrigin
@RequestMapping("absence")
public class AbsenceController {

    @Autowired
    private AbsenceService absenceService;

    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<AbsenceDto>> allAbsence() {
        List<Absence> absences = absenceService.getAllAbsence();
        List<AbsenceDto> absenceDtos = new ArrayList<>();
        for (Absence absence : absences) {
            absenceDtos.add(convertAbsenceToDto(absence, 1));
        }
        return ResponseEntity.status(HttpStatus.OK).body(absenceDtos);
    }

    @GetMapping(path = "/{id}",produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<AbsenceDto> getOneAbsence(@PathVariable Long id){
        Absence absence = absenceService.getAbsenceById(id);
        if(absence==null){
            return new  ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return ResponseEntity.status(HttpStatus.OK).body(convertAbsenceToDto(absence, 1));
    }

/*    @PostMapping()
    public ResponseEntity<?> creer(@Valid @RequestBody AbsenceDto absenceDto, BindingResult bindingResult) {
        try {
            if (bindingResult.hasErrors()) {
                Map<String, String> mapErrors = new HashMap<>();
                for (FieldError error : bindingResult.getFieldErrors()) {
                    mapErrors.put(error.getField(), error.getDefaultMessage());
                }
                return ResponseEntity.badRequest().body(mapErrors);
            }
            Absence absence = convertDtoToAbsence(absenceDto);

            return ResponseEntity.status(HttpStatus.CREATED).body(convertAbsenceToDto(absenceService.create(absence), 1, 1, 1));

        } catch (DataIntegrityViolationException e) {
            Map<String, String> message = StringExtract.keyValueError(e.getMostSpecificCause().getMessage());
            System.out.println("\n\nerreur ici" + message + "\n\n");
            if (message.isEmpty()) {
                message.put("errors", e.getMostSpecificCause().getMessage());
            }
            return ResponseEntity.badRequest().body(message);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Une erreur au niveau du serveur c'est produit");
        }
    }*/


    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> creerOne(@Valid @RequestBody AbsenceDto absenceDto, BindingResult bindingResult) {

        try {
            if (bindingResult.hasErrors()) {
                Map<String, String> mapErrors = new HashMap<>();
                for (FieldError error : bindingResult.getFieldErrors()) {
                    mapErrors.put(error.getField(), error.getDefaultMessage());
                }
                return ResponseEntity.badRequest().body(mapErrors);
            }
            Absence absence = convertDtoToAbsence(absenceDto);
            System.out.println("\n\n Conversion termninée" + absence.toString() + " \n\n");
            absence = absenceService.create(absence);
            return ResponseEntity.status(HttpStatus.CREATED).body(convertAbsenceToDto(absence, 1));
        } catch (DataIntegrityViolationException e) {
            Map<String, String> message = StringExtract.keyValueError(e.getMostSpecificCause().getMessage());
            System.out.println("\n\nerreur ici" + message + "\n\n");
            if (message.isEmpty()) {
                message.put("errors", e.getMostSpecificCause().getMessage());
            }
            return ResponseEntity.badRequest().body(message);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Une erreur au niveau du serveur c'est produit");
        }
    }

    @PutMapping(path = "/{id}",consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> updateOne(@Valid @RequestBody AbsenceDto absenceDto, BindingResult bindingResult, @PathVariable Long id) {
        try {
            if (bindingResult.hasErrors()) {
                Map<String, String> mapErrors = new HashMap<>();
                for (FieldError error : bindingResult.getFieldErrors()) {
                    mapErrors.put(error.getField(), error.getDefaultMessage());
                }
                return ResponseEntity.badRequest().body(mapErrors);
            }
            Absence absence = convertDtoToAbsence(absenceDto);
            System.out.println("\n\n Conversion termninée" + absence.toString() + " \n\n");
            absence = absenceService.update(absence, id);
            if(absence==null){
                return ResponseEntity.notFound().build();
            }
            return ResponseEntity.status(HttpStatus.CREATED).body(convertAbsenceToDto(absence, 1));
        } catch (DataIntegrityViolationException e) {
            Map<String, String> message = StringExtract.keyValueError(e.getMostSpecificCause().getMessage());
            System.out.println("\n\nerreur ici" + message + "\n\n");
            if (message.isEmpty()) {
                message.put("errors", e.getMostSpecificCause().getMessage());
            }
            return ResponseEntity.badRequest().body(message);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Une erreur au niveau du serveur c'est produit");
        }
    }
    public static AbsenceDto convertAbsenceToDto(Absence absence, int depthPersonnel){
        AbsenceDto absenceDto = new AbsenceDto(
                absence.getId(),
                absence.getMessage(),
                absence.getMotif(),
                absence.getValidate(),
                absence.getSubmissionDate(),
                absence.getStart(),
                absence.getEnd(),
                absence.getType()
        );
        if (depthPersonnel > 0) {
            if (absence.getPersonnel()!= null) {
                absenceDto.setPersonnel(convertPersonnelToDto(absence.getPersonnel(), 1, depthPersonnel-1,1, 1, 1,1,1, 0, 0));
            }
        }
        return absenceDto;
    }

    public static Absence convertDtoToAbsence(AbsenceDto absenceDto){
        Absence absence = new Absence(
                absenceDto.getId(),
                absenceDto.getMessage(),
                absenceDto.getMotif(),
                absenceDto.getValidate(),
                absenceDto.getSubmissionDate(),
                absenceDto.getStart(),
                absenceDto.getEnd(),
                absenceDto.getType_()
        );
        if (absenceDto.getPersonnel()!= null) {
            absence.setPersonnel(convertDtoToPersonnel(absenceDto.getPersonnel()));
        }
        return absence;
    }
}
